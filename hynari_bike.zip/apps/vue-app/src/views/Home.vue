<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png" />
  </div>
</template>

<script>
import Vue from 'vue';
//import HelloWorld from '../components/HelloWorld.vue';

export default Vue.extend({
});
</script>
