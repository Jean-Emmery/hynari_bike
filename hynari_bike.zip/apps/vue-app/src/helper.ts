export const server = {
  baseURL: 'http://localhost:3333'
}
