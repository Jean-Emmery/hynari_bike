import { bike } from './bike';

describe('bike', () => {
  it('should work', () => {
    expect(bike()).toEqual('bike');
  });
});
