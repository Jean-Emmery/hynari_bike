export interface IBike {
  id: number;
  name: string;
  pictureUrl: string;
  garage_id: number;
}
